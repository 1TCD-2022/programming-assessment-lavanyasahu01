"""
Filename: Assesment DT1.7 DT1.8
Author: Lavanya Sahu
Date: 18/07/22
Description: NZ QUIZ Question
"""
from random import sample
#Informative Introduction
print("Hii human being! Welcome to the SUPER COOL NZ QUIZ (▀̿Ĺ̯▀̿ ̿)")
print("This quiz will imporve your general knowledge about New Zealand")
print(
    "Hope you are prepared for this Quiz. You will get tested on 10 questions about New Zealand!"
)
print("(っ ͡❛ ͜ʖ ͡❛)っ GOOD LUCK!  (っ ͡❛ ͜ʖ ͡❛)っ")
print("------------------------------------------")

#Questions: (1st List)
Questions = [
    "1. Is Kiwi the national animal of New Zealand?",
    "2. Is Wellington the largest city in NZ?",
    "3. The North Island is larger than the South Island?",
    "4. New Zealand has 5 stars on its national flag",
    "5.The Constitution of Australia names New Zealand as an Australian state?",
    "6.New Zealand is the only country in the world allowed to put Hobbit related imagery on its currency?",
    "7.About 5% of NZ’s population is human. The rest are animals.",
    "8. Is Lake Taupo the largest lake in New Zealand?",
    "9. The kiwifruit is from New Zealand.",
    "10.New Zealand has the longest place name of any English-speaking country in the world. ",
]

#Answer for the questions || 2nd Lists
Answers = ["T", "F", "F", "F", "T", "T", "T", "T", "F", "T"]

#Zipping Questions and Answers
questions_and_answers_1 = list(zip(Questions, Answers))

sample_questions = sample(questions_and_answers_1, 10)

for i in questions_and_answers_1:
    # prints only the question i[0]
    print(i[0])
    user_answer = input("True(t) or False(f): ").strip()
    # checks user input with the answer i[1]
    if user_answer.lower() == i[1].lower():
        print("WHOHOO CORRECT ʕ•́ᴥ•̀ʔっ")
    else:
        print("Incorrect! ( ˘︹˘ )")

#print ending statement
print("_________________________")
print("YOU HAVE OFFICALLY COMPLETED THE QUIZ")
print("(づ｡◕‿‿◕｡)づ CONGRAT!")
print("_________________________")
